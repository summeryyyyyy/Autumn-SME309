module HazardDetectionUnit(
    input [4:0] IF_ID_Rs1,
    input [4:0] IF_ID_Rs2,
    input ID_EX_MemRead,
    input [4:0] ID_EX_Rd,
    input ID_EX_RegWrite,     // Added: Check if EX stage writes to reg
    input [4:0] EX_MEM_Rd,    // Added: Check if MEM stage writes to reg
    input EX_MEM_MemRead,     // Added: Check if MEM stage is Load (actually RegWrite covers it mostly, but specific for Load delay)
    input EX_MEM_RegWrite,    // Added
    input Is_Branch_ID,       // Added: Current ID instr is Branch/Jump?
    
    output reg Stall_Pipeline, // 1: 阻塞流水线
    output reg IF_ID_Write,    // 0: 禁止写入 IF/ID
    output reg PC_Write        // 0: 禁止写入 PC
);
    always @(*) begin
        Stall_Pipeline = 1'b0;
        IF_ID_Write = 1'b1;
        PC_Write = 1'b1;

        // 1. 标准 Load-Use 冒险
        // ID 阶段也就是 IF_ID_Rs1/2，上一条指令在 EX (即 ID_EX...)
        // 如果 EX 是 Load，且目标寄存器冲突 -> Stall 1 cycle
        if (ID_EX_MemRead && (ID_EX_Rd != 5'b0) && 
            ((ID_EX_Rd == IF_ID_Rs1) || (ID_EX_Rd == IF_ID_Rs2))) begin
            Stall_Pipeline = 1'b1;
            IF_ID_Write = 1'b0;
            PC_Write = 1'b0;
        end

        // 2. ID 阶段分支数据冒险 (Control Hazard Data Dependency)
        // 如果当前是 ID 阶段的分支指令，我们需要在 ID 阶段读取寄存器进行比较/计算目标。
        // 如果操作数依赖于流水线中更早的指令 (EX 或 MEM 阶段)，我们必须停止，直到数据准备好 (写入 RegFile)。
        // 为了简化设计并保证稳健性，只要发现依赖就阻塞，等待数据写入寄存器堆 (WB 阶段结束)。
        // 注意：Internal Forwarding (WB->ID) 由寄存器堆内部支持，所以只需检查 EX 和 MEM。
        if (Is_Branch_ID) begin
            // 依赖于 EX 阶段 (ALU 计算 or Load)
            if (ID_EX_RegWrite && (ID_EX_Rd != 5'b0) &&
                ((ID_EX_Rd == IF_ID_Rs1) || (ID_EX_Rd == IF_ID_Rs2))) begin
                Stall_Pipeline = 1'b1;
                IF_ID_Write = 1'b0;
                PC_Write = 1'b0;
            end
            
            // 依赖于 MEM 阶段 (ALU 结果还没写回 or Load 结果)
            if (EX_MEM_RegWrite && (EX_MEM_Rd != 5'b0) &&
                ((EX_MEM_Rd == IF_ID_Rs1) || (EX_MEM_Rd == IF_ID_Rs2))) begin
                Stall_Pipeline = 1'b1;
                IF_ID_Write = 1'b0;
                PC_Write = 1'b0;
            end
        end
    end
endmodule

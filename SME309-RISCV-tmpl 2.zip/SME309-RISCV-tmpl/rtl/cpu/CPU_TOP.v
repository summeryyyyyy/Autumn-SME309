`include "CPU_define.v"
module CPU (
    input         clk,
    input         rst_n,
    input         run, 

    // IROM 接口
    output [31:0]  pc,
    input  [31:0]  instruction,

    // DRAM & MMIO 接口
    output [31:0]  perip_addr,
    output [31:0]  perip_wdata,
    output         perip_wen,
    output [1:0]   perip_mask,
    input  [31:0]  perip_rdata
);

    // ========================================================================
    // 内部信号与寄存器定义
    // ========================================================================
    
    // --- PC 信号 ---
    wire [31:0] PC_Next;
    wire [31:0] PC_Current;
    wire PC_Write_En;
    
    // --- IF 取指阶段信号 ---
    wire [31:0] IF_Instr = instruction;
    
    // --- IF/ID 流水线寄存器 ---
    reg [31:0] IF_ID_PC;
    reg [31:0] IF_ID_Instr;
    wire IF_ID_Write;
    wire IF_ID_Flush;
    
    // --- ID 译码阶段信号 ---
    wire [6:0] ID_Opcode;
    wire [2:0] ID_Func3;
    wire [6:0] ID_Func7;
    wire [4:0] ID_Rs1_Addr, ID_Rs2_Addr, ID_Rd_Addr;
    wire [31:0] ID_Rs1_Data, ID_Rs2_Data;
    wire [31:0] ID_Imm;
    
    // ID 控制信号
    wire [4:0] ID_ALUC;
    wire ID_MemtoReg;
    wire ID_ALUSrc1;
    wire [1:0] ID_ALUSrc2;
    wire ID_RegWrite;
    wire [1:0] ID_MemWrite;
    wire [2:0] ID_MemRead;
    wire [2:0] ID_ExtOP;
    wire [1:0] ID_PcorRs1;
    wire ID_Lui;
    
    // ID 分支处理 (Early BTA)
    wire [31:0] ID_Branch_Target;
    wire ID_Branch_Taken;
    wire ID_Is_Branch_Instruction; // 辅助一般分支、跳转判断
    
    // 冒险处理
    wire Stall_Hazard; // ID 阶段检测到的冒险 (Load-Use 或 Branch Data)
    wire Flash_ID;     // ID 阶段决定跳转，冲刷 IF/ID (Bubble 1)
    
    // --- ID/EX 流水线寄存器 ---
    reg [31:0] ID_EX_PC;
    reg [31:0] ID_EX_Rs1_Data, ID_EX_Rs2_Data;
    reg [31:0] ID_EX_Imm;
    reg [4:0] ID_EX_Rs1_Addr, ID_EX_Rs2_Addr, ID_EX_Rd_Addr;
    
    // ID/EX 控制信号
    reg [4:0] ID_EX_ALUC;
    reg ID_EX_MemtoReg;
    reg ID_EX_ALUSrc1;
    reg [1:0] ID_EX_ALUSrc2;
    reg ID_EX_RegWrite;
    reg [1:0] ID_EX_MemWrite;
    reg [2:0] ID_EX_MemRead;
    reg [1:0] ID_EX_PcorRs1;
    reg ID_EX_Lui;
    // wire ID_EX_Flush; // 不再需要上一级 flush 下一级，因为分支在 ID 解决

    // --- EX 执行阶段信号 ---
    wire [31:0] EX_ForwardA_Data;
    wire [31:0] EX_ForwardB_Data;
    wire [31:0] EX_ALU_SrcA;
    wire [31:0] EX_ALU_SrcB;
    wire [31:0] EX_ALU_Result;
    wire EX_Condition_Branch; // 仅作为 ALU 状态输出，不用于控制流
    
    wire [1:0] ForwardA;
    wire [1:0] ForwardB;

    // --- EX/MEM 流水线寄存器 ---
    reg [31:0] EX_MEM_ALUResult;
    reg [31:0] EX_MEM_WriteData;
    reg [4:0] EX_MEM_Rd_Addr;
    
    // EX/MEM 控制信号
    reg EX_MEM_RegWrite;
    reg EX_MEM_MemtoReg;
    reg [1:0] EX_MEM_MemWrite;
    reg [2:0] EX_MEM_MemRead;
    
    // --- MEM 访存阶段信号 ---
    wire [31:0] MEM_ReadData_Raw; 
    wire [31:0] MEM_ReadData_Final;
    
    // --- MEM/WB 流水线寄存器 ---
    reg [31:0] MEM_WB_ReadData;
    reg [31:0] MEM_WB_ALUResult;
    reg [4:0] MEM_WB_Rd_Addr;
    reg MEM_WB_RegWrite;
    reg MEM_WB_MemtoReg;
    
    // --- WB 写回阶段信号 ---
    wire [31:0] WB_WriteData;

    // ========================================================================
    // 第 1 阶段: IF (取指)
    // ========================================================================
    
    assign pc = PC_Current;
    
    // NextPC 逻辑:
    // 如果 ID 阶段判定分支发生 (ID_Branch_Taken)，直接跳到 ID_Branch_Target
    // 否则正常 PC+4
    assign PC_Next = ID_Branch_Taken ? ID_Branch_Target : (PC_Current + 4);

    ProgramCounter ProgramCounter(
        .CLK(clk),
        .Reset(~rst_n),
        .PC_Write(PC_Write_En), // 来自 HazardDetectionUnit
        .NextPC(PC_Next),
        .PC(PC_Current)
    );

    // IF/ID 流水线寄存器
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            IF_ID_PC <= 0;
            IF_ID_Instr <= 0;
        end
        else if (Flash_ID) begin
            IF_ID_PC <= 0;
            IF_ID_Instr <= 0; // 跳转发生，冲刷刚刚取到的错误指令
        end
        else if (IF_ID_Write) begin
            IF_ID_PC <= PC_Current;
            IF_ID_Instr <= IF_Instr;
        end
        // Else Stall: Hold
    end

    // ========================================================================
    // 第 2 阶段: ID (译码 + 分支判定)
    // ========================================================================

    Decoder Decoder(
        .instr(IF_ID_Instr),
        .opcode(ID_Opcode),
        .func3(ID_Func3),
        .func7(ID_Func7),
        .rd(ID_Rd_Addr),
        .rs1(ID_Rs1_Addr),
        .rs2(ID_Rs2_Addr)
    );

    Control Control(
        .opcode(ID_Opcode),
        .func3(ID_Func3),
        .func7(ID_Func7),
        .aluc(ID_ALUC),
        .aluOut_WB_memOut(ID_MemtoReg),
        .rs1Data_EX_PC(ID_ALUSrc1), 
        .rs2Data_EX_imm32_4(ID_ALUSrc2),
        .write_reg(ID_RegWrite),
        .write_mem(ID_MemWrite), 
        .read_mem(ID_MemRead),
        .extOP(ID_ExtOP),
        .pcImm_NEXTPC_rs1Imm(ID_PcorRs1),
        .lui(ID_Lui)
    );

    Extend Extend(
        .instr(IF_ID_Instr),
        .extOP(ID_ExtOP),
        .imm_32(ID_Imm)
    );

    RegisterFile RegisterFile(
        .CLK(clk),
        .WE3(MEM_WB_RegWrite), 
        .A1(ID_Rs1_Addr),
        .A2(ID_Rs2_Addr),
        .A3(MEM_WB_Rd_Addr),
        .WD3(WB_WriteData),
        .RD1(ID_Rs1_Data),
        .RD2(ID_Rs2_Data)
    );

    // --- ID 阶段分支判断逻辑 (Early BTA) ---
    // 识别当前指令是否为 Branch/Jump
    wire Is_JAL  = (ID_Opcode == 7'b1101111);
    wire Is_JALR = (ID_Opcode == 7'b1100111);
    wire Is_Branch = (ID_Opcode == 7'b1100011);
    assign ID_Is_Branch_Instruction = Is_JAL | Is_JALR | Is_Branch;

    // 比较器 (使用寄存器原始值，如果数据冒险 HazardUnit 会 Stall 等到数据准备好)
    reg Condition_Met;
    always @(*) begin
        case (ID_Func3)
            3'b000: Condition_Met = (ID_Rs1_Data == ID_Rs2_Data); // BEQ
            3'b001: Condition_Met = (ID_Rs1_Data != ID_Rs2_Data); // BNE
            3'b100: Condition_Met = ($signed(ID_Rs1_Data) < $signed(ID_Rs2_Data)); // BLT
            3'b101: Condition_Met = ($signed(ID_Rs1_Data) >= $signed(ID_Rs2_Data)); // BGE
            3'b110: Condition_Met = (ID_Rs1_Data < ID_Rs2_Data); // BLTU
            3'b111: Condition_Met = (ID_Rs1_Data >= ID_Rs2_Data); // BGEU
            default: Condition_Met = 0;
        endcase
    end
    
    // 判断是否跳转
    assign ID_Branch_Taken = (Is_Branch && Condition_Met) || Is_JAL || Is_JALR;

    // 计算跳转目标
    // JAL/Branch: PC + Imm
    // JALR: Rs1 + Imm
    assign ID_Branch_Target = Is_JALR ? (ID_Rs1_Data + ID_Imm) : (IF_ID_PC + ID_Imm);

    // 关键：如果 ID 发生跳转，需要冲刷 IF/ID 寄存器 (Flash_ID)
    // 但必须确保没有数据冒险 (Stall_Hazard)。如果不判断，可能会用旧数据做出错误跳转。
    // 如果 Stall_Hazard = 1，PC 和 IF/ID 保持不变，不会取新指令，自然也不会误跳转（等待 Stall 结束）
    // 所以 ID_Branch_Taken 必须与 !Stall_Hazard 结合吗？
    // HazardUnit 会把 PC_Write 拉低。如果 PC_Write=0，PC 不更新。
    // 此时 IF_ID_Write=0，IF/ID 不更新。
    // 所以我们应该只在 !Stall_Hazard 时允许 Flush，或者 Flash 的优先级在 Stall 处理之后。
    // 此处简化：如果 Stall，Flash 信号应当屏蔽，避免在等待数据时丢弃当前指令。
    assign Flash_ID = ID_Branch_Taken && !Stall_Hazard; 


    // 冒险检测单元 (升级版)
    HazardDetectionUnit HazardUnit(
        .IF_ID_Rs1(ID_Rs1_Addr),
        .IF_ID_Rs2(ID_Rs2_Addr),
        .ID_EX_MemRead(ID_EX_MemRead[2] | ID_EX_MemRead[1] | ID_EX_MemRead[0]), // 之前的 MemRead 是 [2:0]
        .ID_EX_Rd(ID_EX_Rd_Addr),
        // 新增接口用于 ID 分支检测
        .ID_EX_RegWrite(ID_EX_RegWrite),
        .EX_MEM_Rd(EX_MEM_Rd_Addr),
        .EX_MEM_MemRead(|EX_MEM_MemRead),
        .EX_MEM_RegWrite(EX_MEM_RegWrite),
        .Is_Branch_ID(ID_Is_Branch_Instruction),
        
        .Stall_Pipeline(Stall_Hazard),
        .IF_ID_Write(IF_ID_Write),
        .PC_Write(PC_Write_En)
    );

    
    // ID/EX 流水线寄存器
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            ID_EX_PC <= 0;
            ID_EX_Rs1_Data <= 0;
            ID_EX_Rs2_Data <= 0;
            ID_EX_Imm <= 0;
            ID_EX_Rs1_Addr <= 0;
            ID_EX_Rs2_Addr <= 0;
            ID_EX_Rd_Addr <= 0;
            ID_EX_ALUC <= 0;
            ID_EX_MemtoReg <= 0;
            ID_EX_ALUSrc1 <= 0;
            ID_EX_ALUSrc2 <= 0;
            ID_EX_RegWrite <= 0;
            ID_EX_MemWrite <= 0;
            ID_EX_MemRead <= 0;
            ID_EX_PcorRs1 <= 0;
            ID_EX_Lui <= 0;
        end
        else if (Stall_Hazard || Flash_ID) begin // 遇到冒险 或 ID 跳转发生时，ID/EX 插入气泡
            // Insert Bubble / NOP
            ID_EX_RegWrite <= 0;
            ID_EX_MemWrite <= 0;
            ID_EX_MemRead <= 0;
            ID_EX_PcorRs1 <= 0; 
            
            ID_EX_Rs1_Addr <= 0; // 清零地址防止下一级误前递
            ID_EX_Rs2_Addr <= 0;
            ID_EX_Rd_Addr <= 0;
        end
        else begin
            // 正常传递
            ID_EX_PC <= IF_ID_PC;
            ID_EX_Rs1_Data <= ID_Rs1_Data;
            ID_EX_Rs2_Data <= ID_Rs2_Data;
            ID_EX_Imm <= ID_Imm;
            ID_EX_Rs1_Addr <= ID_Rs1_Addr;
            ID_EX_Rs2_Addr <= ID_Rs2_Addr;
            ID_EX_Rd_Addr <= ID_Rd_Addr;
            
            ID_EX_ALUC <= ID_ALUC;
            ID_EX_MemtoReg <= ID_MemtoReg;
            ID_EX_ALUSrc1 <= ID_ALUSrc1;
            ID_EX_ALUSrc2 <= ID_ALUSrc2;
            ID_EX_RegWrite <= ID_RegWrite;
            ID_EX_MemWrite <= ID_MemWrite;
            ID_EX_MemRead <= ID_EX_MemRead;
            ID_EX_PcorRs1 <= ID_PcorRs1;
            ID_EX_Lui <= ID_Lui;
        end
    end

    // ========================================================================
    // 第 3 阶段: EX (执行)
    // ========================================================================

    ForwardingUnit ForwardingUnit(
        .ID_EX_Rs1(ID_EX_Rs1_Addr),
        .ID_EX_Rs2(ID_EX_Rs2_Addr),
        .EX_MEM_Rd(EX_MEM_Rd_Addr),
        .EX_MEM_RegWrite(EX_MEM_RegWrite),
        .MEM_WB_Rd(MEM_WB_Rd_Addr),
        .MEM_WB_RegWrite(MEM_WB_RegWrite),
        .ForwardA(ForwardA),
        .ForwardB(ForwardB)
    );

    assign EX_ForwardA_Data = (ForwardA == 2'b10) ? EX_MEM_ALUResult :
                              (ForwardA == 2'b01) ? WB_WriteData :
                              ID_EX_Rs1_Data;
                              
    assign EX_ForwardB_Data = (ForwardB == 2'b10) ? EX_MEM_ALUResult :
                              (ForwardB == 2'b01) ? WB_WriteData :
                              ID_EX_Rs2_Data;

    assign EX_ALU_SrcA = ID_EX_Lui ? 32'b0 : 
                         ID_EX_ALUSrc1 ? ID_EX_PC : EX_ForwardA_Data;

    assign EX_ALU_SrcB = ID_EX_ALUSrc2[1] ? 32'd4 :
                         ID_EX_ALUSrc2[0] ? ID_EX_Imm : EX_ForwardB_Data;

    Alu Alu(
        .aluc(ID_EX_ALUC),
        .a(EX_ALU_SrcA),
        .b(EX_ALU_SrcB),
        .out(EX_ALU_Result),
        .condition_branch(EX_Condition_Branch) // 保留但不用于 Control
    );

    // *已移除 EX 阶段的分支逻辑 (EX_Branch_Taken, etc)*

    // EX/MEM 流水线寄存器
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            EX_MEM_ALUResult <= 0;
            EX_MEM_WriteData <= 0;
            EX_MEM_Rd_Addr <= 0;
            EX_MEM_RegWrite <= 0;
            EX_MEM_MemtoReg <= 0;
            EX_MEM_MemWrite <= 0;
            EX_MEM_MemRead <= 0;
        end
        else begin
            // 正常传递
            EX_MEM_ALUResult <= EX_ALU_Result;
            EX_MEM_WriteData <= EX_ForwardB_Data; 
            EX_MEM_Rd_Addr <= ID_EX_Rd_Addr;
            
            EX_MEM_RegWrite <= ID_EX_RegWrite;
            EX_MEM_MemtoReg <= ID_EX_MemtoReg;
            EX_MEM_MemWrite <= ID_EX_MemWrite;
            EX_MEM_MemRead <= ID_EX_MemRead; 
        end
    end

    // ========================================================================
    // 第 4 阶段: MEM (访存)
    // ========================================================================

    assign perip_addr = EX_MEM_ALUResult;
    assign perip_wdata = EX_MEM_WriteData;
    assign perip_wen = !(EX_MEM_MemWrite == 2'b11);
    
    assign perip_mask = (perip_wen) ? EX_MEM_MemWrite : EX_MEM_MemRead[1:0];

    Memdata u_Memdata(
        .MemRead(EX_MEM_MemRead),
        .perip_rdata(perip_rdata),
        .real_rdata(MEM_ReadData_Final)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            MEM_WB_ReadData <= 0;
            MEM_WB_ALUResult <= 0;
            MEM_WB_Rd_Addr <= 0;
            MEM_WB_RegWrite <= 0;
            MEM_WB_MemtoReg <= 0;
        end
        else begin
            MEM_WB_ReadData <= MEM_ReadData_Final;
            MEM_WB_ALUResult <= EX_MEM_ALUResult;
            MEM_WB_Rd_Addr <= EX_MEM_Rd_Addr;
            MEM_WB_RegWrite <= EX_MEM_RegWrite;
            MEM_WB_MemtoReg <= EX_MEM_MemtoReg;
        end
    end

    // ========================================================================
    // 第 5 阶段: WB (写回)
    // ========================================================================

    // 写回数据选择
    assign WB_WriteData = MEM_WB_MemtoReg ? MEM_WB_ReadData : MEM_WB_ALUResult;

endmodule
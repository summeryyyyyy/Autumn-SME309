module ProgramCounter(
    input CLK,
    input Reset,
    input PC_Write,
    input [31:0] NextPC,
    output reg [31:0] PC
);

    always @(posedge CLK or posedge Reset) begin
        if (Reset) begin
            PC <= 32'h00000000;
        end
        else if (PC_Write) begin
            PC <= NextPC;
        end
        // else hold value
    end

endmodule

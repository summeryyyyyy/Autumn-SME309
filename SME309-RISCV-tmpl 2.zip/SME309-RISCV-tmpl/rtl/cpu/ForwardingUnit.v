module ForwardingUnit(
    input [4:0] ID_EX_Rs1,
    input [4:0] ID_EX_Rs2,
    input [4:0] EX_MEM_Rd,
    input EX_MEM_RegWrite,
    input [4:0] MEM_WB_Rd,
    input MEM_WB_RegWrite,
    output reg [1:0] ForwardA,
    output reg [1:0] ForwardB
);

    always @(*) begin
        ForwardA = 2'b00; // 默认来源：ID/EX 阶段的寄存器值
        ForwardB = 2'b00;

        // EX 阶段前递 (优先级最高)
        // 如果 EX/MEM 阶段的指令也是写寄存器，且目标寄存器就是当前 ALU 输入源，则直接从 EX/MEM 旁路过来
        if (EX_MEM_RegWrite && (EX_MEM_Rd != 5'b0) && (EX_MEM_Rd == ID_EX_Rs1))
            ForwardA = 2'b10;
        
        if (EX_MEM_RegWrite && (EX_MEM_Rd != 5'b0) && (EX_MEM_Rd == ID_EX_Rs2))
            ForwardB = 2'b10;

        // MEM 阶段前递 (优先级次之)
        // 如果 MEM/WB 阶段的指令写寄存器，且目标寄存器是 ALU 输入源，且 **没有** 被 EX 阶段的前递截获
        if (MEM_WB_RegWrite && (MEM_WB_Rd != 5'b0) && (MEM_WB_Rd == ID_EX_Rs1) && 
            !(EX_MEM_RegWrite && (EX_MEM_Rd != 5'b0) && (EX_MEM_Rd == ID_EX_Rs1))) 
            ForwardA = 2'b01;

        if (MEM_WB_RegWrite && (MEM_WB_Rd != 5'b0) && (MEM_WB_Rd == ID_EX_Rs2) && 
            !(EX_MEM_RegWrite && (EX_MEM_Rd != 5'b0) && (EX_MEM_Rd == ID_EX_Rs2)))
            ForwardB = 2'b01;
    end
endmodule

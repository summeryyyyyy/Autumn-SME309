module Memdata(
    input [2:0] MemRead,
    input [31:0] perip_rdata,
    output reg [31:0] real_rdata
);

always @(*) begin
    case (MemRead)
        3'b000: // LBU - 无符号字节加载
            real_rdata = {24'b0, perip_rdata[7:0]};
            
        3'b001: // LHU - 无符号半字加载
            real_rdata = {16'b0, perip_rdata[15:0]};
            
        3'b010: // LW - 字加载
            real_rdata = perip_rdata;
            
        3'b100: // LB - 有符号字节加载
            real_rdata = {{24{perip_rdata[7]}}, perip_rdata[7:0]};
            
        3'b101: // LH - 有符号半字加载
            real_rdata = {{16{perip_rdata[15]}}, perip_rdata[15:0]};
            
        default: // 默认按字处理
            real_rdata = perip_rdata;
    endcase
end

endmodule

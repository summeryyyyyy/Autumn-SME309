vopt -64 +acc -l elaborate.log -L xil_defaultlib -L xpm -L dist_mem_gen_v8_0_12 -L unisims_ver -L unimacro_ver -L secureip -work xil_defaultlib xil_defaultlib.IROM xil_defaultlib.glbl -o IROM_opt

// Created by IP Generator (Version 2022.2-SP1-Lite build 132640)
// Instantiation Template
//
// Insert the following codes into your Verilog file.
//   * Change the_instance_name to your own instance name.
//   * Change the signal names in the port associations


pll the_instance_name (
  .clkout0(clkout0),    // output
  .clkout1(clkout1),    // output
  .lock(lock),          // output
  .clkin1(clkin1),      // input
  .rst(rst)             // input
);
